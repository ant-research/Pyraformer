import torch
from collections import OrderedDict

checkpoint = torch.load('best_model.pth')
state_dict = checkpoint['model']
new_state_dict = OrderedDict()
for key in state_dict:
  new_key = key.replace('module.', '')
  new_state_dict[new_key] = state_dict[key]
  
checkpoint['model'] = new_state_dict
torch.save(checkpoint, 'replaced_model.pth')

